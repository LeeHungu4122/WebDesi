
$(document).ready(function() {
   $('.menu > ul > li').on('mouseover', function() {
      $('.sub').stop().slideDown();
       $('.bg').stop().slideDown();
   }); 
    
    $('.menu > ul > li').on('mouseleave', function() {
      $('.sub').stop().slideUp();
        $('.bg').stop().slideUp();
   }); 
    
    start();
    
    var imgs = 2;
    var now = 0;
    
    function start() {
        $('.visual > a').eq(0).siblings().css("opacity", 0)
        setInterval(function() {
           slide()
        }, 3000);
    }
    
    function slide() {
        now = now == imgs ? 0 : now += 1;
        
        $('.visual > a').eq(now - 1).css('opacity', 0)
        $('.visual > a').eq(now).css('opacity', 1)
    }
    
    $('.click').on('click', function() {
       $('.popup').show();
    });
    
    $('.btn').on('click', function() {
       $('.popup').hide();
    });
});